The requirements for running all the code in the final assignment folder are:

- python 3.9 or higher 

install ema_workbench: 

pip install ema_workbench

The rest of the dependencies are imported in the python files and notebooks by running them.

Make sure to at least have the following installs:

pip install seaborn
pip install matplotlib
pip install pandas
pip install numpy 

